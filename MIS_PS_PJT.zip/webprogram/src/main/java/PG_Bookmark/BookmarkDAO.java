package PG_Bookmark;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.PageContext;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import PG_Board.BoardBean;
import PG_Board.DBConnectionMgr;

import java.sql.DriverManager;
import java.util.ArrayList;

public class BookmarkDAO {

	private Connection conn;
	private DBConnectionMgr pool;
	private ResultSet rs;
	
	public BookmarkDAO() {
		try {
			pool = DBConnectionMgr.getInstance();
		}catch (Exception e) {
			e.printStackTrace();
		}
	}

	public ArrayList<BoardBean> getList(String id, int pageNumber){
		ArrayList<BoardBean> list = new ArrayList<BoardBean> ();
		
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		
		try {
			con = pool.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				sql = "SELECT * FROM tblboard WHERE num IN (select num from bookmark where id = ?) ORDER BY num DESC LIMIT 10";
				BoardBean board = new BoardBean();
				
				board.setNum(rs.getInt("num"));
				board.setName(rs.getString("name"));
				board.setSubject(rs.getString("subject"));
				board.setPos(rs.getInt("pos"));
				board.setRef(rs.getInt("ref"));
				board.setDepth(rs.getInt("depth"));
				board.setRegdate(rs.getString("regdate"));
				board.setCount(rs.getInt("count"));
				board.setCategory(rs.getInt("category"));
				
				list.add(board);
			}
		}catch(Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return list;
	}

	
	public int write(String id, int num) {
		String SQL = "INSERT INTO bookmark VALUES(?, ?)";
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setString(1, id);
			pstmt.setInt(2, num);
			pstmt.executeUpdate();
			return 1;
		}catch(Exception e) {
			e.printStackTrace();
		}
		return -1; 
	}
	
	public ArrayList<Bookmark> getBookmark(String id, int num) {
		String SQL = "SELECT * FROM bookmark WHERE id = ? AND num = ?";
		ArrayList<Bookmark> list = new ArrayList<Bookmark>();
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setString(1, id);
			pstmt.setInt(2, num);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				Bookmark bookmark = new Bookmark();
				bookmark.setNum(rs.getInt(1));
				bookmark.setId(rs.getString(2));
				list.add(bookmark);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	
	public int delete(String id, int num) {
		String SQL = "DELETE FROM bookmark WHERE num = ? AND id = ?";
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setInt(1, num);
			pstmt.setString(2, id);
			return pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return -1;
	}
}