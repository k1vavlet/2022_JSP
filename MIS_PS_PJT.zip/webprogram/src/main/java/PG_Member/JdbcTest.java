package PG_Member;

import java.sql.*;

public class JdbcTest {
	public static void main(String args[]) {
		Connection con;
		
		try {
			Class.forName("org.mariadb.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mariadb://localhost:3306/mis_pjt", "root", "1234");
			System.out.println("Success");
		} catch(SQLException ex) {
			System.out.println("SQLException" + ex);
		} catch(Exception ex) {
			System.out.println("Exception" + ex);
		}
	}
}
