package PG_Member;

public class RegisterBean {
	private String std_id;
	private String std_pwd;
	private String std_name;
	private String std_email;
	private String std_phone;
	private String zipcode;
	private String address;
	public String getStd_id() {
		return std_id;
	}
	public void setStd_id(String std_id) {
		this.std_id = std_id;
	}
	public String getStd_pwd() {
		return std_pwd;
	}
	public void setStd_pwd(String std_pwd) {
		this.std_pwd = std_pwd;
	}
	public String getStd_name() {
		return std_name;
	}
	public void setStd_name(String std_name) {
		this.std_name = std_name;
	}
	public String getStd_email() {
		return std_email;
	}
	public void setStd_email(String std_email) {
		this.std_email = std_email;
	}
	public String getStd_phone() {
		return std_phone;
	}
	public void setStd_phone(String std_phone) {
		this.std_phone = std_phone;
	}
	public String getZipcode() {
		return zipcode;
	}
	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
}
