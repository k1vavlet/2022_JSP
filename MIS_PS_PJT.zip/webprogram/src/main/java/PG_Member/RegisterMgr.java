package PG_Member;

import java.sql.*;
import java.util.Vector;

import PG_Member_002.M_DBConnectionMgr;

public class RegisterMgr {
	
		private M_DBConnectionMgr pool = null;

		private final String JDBC_DRIVER = "org.mariadb.jdbc.Driver";
		private final String JDBC_URL = "jdbc:mariadb://localhost:3306/mis_pjt";
		private final String USER = "root";
		private final String PASS = "1234";
		
		public RegisterMgr() {
			try {
				pool = M_DBConnectionMgr.getInstance();
				//Class.forName(JDBC_DRIVER);
			} catch(Exception e) {
				System.out.println("Error : JDBC ����̹� �ε� ����");
			}
		}
		
		public Vector<RegisterBean> getRegisterList() {
			Connection conn = null;
			Statement stmt = null;
			ResultSet rs = null;
			Vector<RegisterBean> vlist = new Vector<RegisterBean>();
			
			try {
				//conn = DriverManager.getConnection(JDBC_URL, USER, PASS);
				conn = pool.getConnection();
				String strQuery = "select * from student";
				stmt = conn.createStatement();
				rs = stmt.executeQuery(strQuery);
				
				while(rs.next()) {
					RegisterBean regBean = new RegisterBean();
					regBean.setStd_id(rs.getString("std_id"));
					regBean.setStd_pwd(rs.getString("std_pwd"));
					regBean.setStd_name(rs.getString("std_name"));
					regBean.setStd_email(rs.getString("std_email"));
					regBean.setStd_phone(rs.getString("std_phone"));
					regBean.setZipcode(rs.getString("zipcode"));
					regBean.setAddress(rs.getString("address"));
					vlist.add(regBean);
				}
			} catch(Exception ex) {
				System.out.println("Exception" + ex);
			} finally {
				if(rs != null) {
					try {
						rs.close();
					} catch(SQLException e) {}
				}
				if(stmt != null) {
					try {
						stmt.close();
					} catch(SQLException e) {}
				}
				if(conn != null) {
					try {
						conn.close();
					} catch(SQLException e) {}
				}
			}
		return vlist;
	}
}
